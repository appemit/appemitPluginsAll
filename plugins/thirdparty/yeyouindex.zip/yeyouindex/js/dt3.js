;(function(){
    var obj={};
    var arr=$("#cid").val().split("__");

    obj.cid=arr[0];
    obj.ccid=$("#ccid").val();
    obj.game_id=$("#from_game").val()||0;
    obj.server_id=$("#from_server").val()||0;
    obj.creative_id=arr[1]||"";

    var curr_url=location.href;

    obj.domain_name=location.hostname;

    obj.on_off=(curr_url.indexOf("/off/")!=-1)?"off":"on";

    obj.hasParent=(top.location != location)?true:false;

    // obj.ccid=obj.hasParent?(obj.ccid+"_fy_dt1"):obj.ccid+"_dt1";

    obj.map={
        "{domain_name}":obj.domain_name,
        "{switch}":obj.on_off,
        "{num1}":obj.cid,
        "{num2}":encodeURIComponent(obj.ccid)
    }

    window.params=obj;
})();

function isMobile(){//是移动端
    var u = navigator.userAgent;
    return !!u.match(/AppleWebKit.*Mobile.*/);
}

function showpageReq(url) {
    var cid=params.cid;
    var ccid=params.ccid;
    var game_id=params.game_id;
    var server_id=params.server_id;
    var creative_id=params.creative_id;
    $.ajax({
        type:"GET",
        url:url,
        data:{
            "cid":cid,
            "ccid":ccid,
            "game_id":game_id,
            "server_id":server_id,
            "creative_id":creative_id
        }
    });
}

function writeParams(href){
    return href.replace(/(\{[a-z0-9_]+})+?/g,function(v){
        return params.map[v]
    })
}

$(".modify_url").each(function(i,ele){
    var href=$(ele).attr("href");
    // href=params.hasParent?href.slice(0,-1)+"_dt1":href;
    $(ele).attr("href",writeParams(href));
})

function getDate(){
    var date=new Date();
    var month=date.getMonth()+1;
    var day=date.getDate();
    $("#year").text(date.getFullYear());
    month=month<10?'0'+month:month;
    return month+'-'+day;
}

$(".date").text(getDate());

window.onload=function(){
    //判断是否在iframe中
    if(self!=top){
        console.log("在iframe中")
        var iframeBox=window.parent.document.getElementById("iframeBox");
        if(iframeBox.style.display=="block"){
            showpageReq("http://web.qbdgame.com/");
        }
    }else{
        console.log("不在iframe中")
        if(isMobile()){
            console.log("移动端")
            /*document.title="千百度H5游戏";
            rendMTemp();//渲染移动端模板
            $id("main").style.display = "none";
            $id("iframeBox").style.display="block";*/
        }else{
            console.log("PC端")
            // showpageReq("http://web.qbdgame.com/");
        }
        showpageReq("http://web.qbdgame.com/");
    }
}

//加入收藏
function addFavorite(){
    if (document.all){
        try{
            window.external.addFavorite(window.location.href,document.title);
        }catch(e){
            alert( "加入收藏失败，请使用Ctrl+D进行添加" );
        }

    }else if (window.sidebar){
        window.sidebar.addPanel(document.title, window.location.href, "");
     }else{
        alert( "加入收藏失败，请使用Ctrl+D进行添加" );
    }
}
 
//设为首页 <a onclick="SetHome(this,window.location)" >设为首页</a>
function SetHome(obj, vrl) {
    //debugger;
    //谷歌下vrl为数组对象非字符串
    var homePage=vrl;
    try {
        obj.style.behavior = 'url(#default#homepage)';
        obj.setHomePage(homePage);
    } catch (e) {
        if (window.netscape) {
            try {
                netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
            } catch (e) {
                alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
            }
            var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
            prefs.setCharPref('browser.startup.homepage', homePage);
        }
    }
}